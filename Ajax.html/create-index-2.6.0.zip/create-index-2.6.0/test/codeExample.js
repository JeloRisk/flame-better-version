import _ from 'lodash';

export default (code) => {
  return _.trim(code) + '\n\n';
};
