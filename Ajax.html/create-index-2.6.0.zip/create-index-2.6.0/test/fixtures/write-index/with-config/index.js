// @create-index {"ignore":["/bar.js$/"]}

export { default as foo } from './foo.js';

