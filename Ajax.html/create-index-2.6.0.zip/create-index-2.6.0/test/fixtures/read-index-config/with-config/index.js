// @create-index {"ignore": ["/foo.js$/"]}
